import 'dart:async';
import 'dart:math';
import 'package:flutter/material.dart';
import 'package:flutter/scheduler.dart';
import 'package:flutter/services.dart';

void main() {
  WidgetsFlutterBinding.ensureInitialized();
  // Allow all orientations: portrait, landscape left, landscape right
  SystemChrome.setPreferredOrientations([
    DeviceOrientation.portraitUp,
    DeviceOrientation.portraitDown,
    DeviceOrientation.landscapeLeft,
    DeviceOrientation.landscapeRight,
  ]);
  runApp(const PianoPracticeApp());
}

enum NoteHitStatus { pending, perfect, good, miss }

class NoteEvent {
  final int pitch; // MIDI note 48 (C3) to 84 (C6)
  final double startSeconds;
  final double durationSeconds;
  NoteHitStatus status;

  NoteEvent({
    required this.pitch,
    required this.startSeconds,
    required this.durationSeconds,
    this.status = NoteHitStatus.pending,
  });

  NoteEvent copy() => NoteEvent(
        pitch: pitch,
        startSeconds: startSeconds,
        durationSeconds: durationSeconds,
        status: status,
      );
}

class SongData {
  final String title;
  final double bpm;
  final List<NoteEvent> notes;

  SongData({required this.title, required this.bpm, required this.notes});
}

final Map<String, SongData> kSongs = {
  'fur_elise': SongData(
    title: 'Beethoven — Für Elise',
    bpm: 125,
    notes: [
      NoteEvent(pitch: 76, startSeconds: 0.0, durationSeconds: 0.25),
      NoteEvent(pitch: 75, startSeconds: 0.25, durationSeconds: 0.25),
      NoteEvent(pitch: 76, startSeconds: 0.50, durationSeconds: 0.25),
      NoteEvent(pitch: 75, startSeconds: 0.75, durationSeconds: 0.25),
      NoteEvent(pitch: 76, startSeconds: 1.00, durationSeconds: 0.25),
      NoteEvent(pitch: 71, startSeconds: 1.25, durationSeconds: 0.25),
      NoteEvent(pitch: 74, startSeconds: 1.50, durationSeconds: 0.25),
      NoteEvent(pitch: 72, startSeconds: 1.75, durationSeconds: 0.25),
      NoteEvent(pitch: 69, startSeconds: 2.00, durationSeconds: 0.60),
      NoteEvent(pitch: 57, startSeconds: 2.20, durationSeconds: 0.40),
      NoteEvent(pitch: 64, startSeconds: 2.60, durationSeconds: 0.40),
      NoteEvent(pitch: 69, startSeconds: 3.00, durationSeconds: 0.40),
      NoteEvent(pitch: 71, startSeconds: 3.40, durationSeconds: 0.50),
      NoteEvent(pitch: 60, startSeconds: 3.60, durationSeconds: 0.40),
      NoteEvent(pitch: 64, startSeconds: 4.00, durationSeconds: 0.40),
      NoteEvent(pitch: 71, startSeconds: 4.40, durationSeconds: 0.40),
      NoteEvent(pitch: 72, startSeconds: 4.80, durationSeconds: 0.50),
      NoteEvent(pitch: 64, startSeconds: 5.20, durationSeconds: 0.30),
      NoteEvent(pitch: 76, startSeconds: 5.60, durationSeconds: 0.25),
      NoteEvent(pitch: 75, startSeconds: 5.85, durationSeconds: 0.25),
      NoteEvent(pitch: 76, startSeconds: 6.10, durationSeconds: 0.25),
      NoteEvent(pitch: 75, startSeconds: 6.35, durationSeconds: 0.25),
      NoteEvent(pitch: 76, startSeconds: 6.60, durationSeconds: 0.25),
      NoteEvent(pitch: 71, startSeconds: 6.85, durationSeconds: 0.25),
      NoteEvent(pitch: 74, startSeconds: 7.10, durationSeconds: 0.25),
      NoteEvent(pitch: 72, startSeconds: 7.35, durationSeconds: 0.25),
      NoteEvent(pitch: 69, startSeconds: 7.60, durationSeconds: 0.80),
    ],
  ),
  'minuet_g': SongData(
    title: 'J.S. Bach — Minuet in G',
    bpm: 110,
    notes: [
      NoteEvent(pitch: 74, startSeconds: 0.0, durationSeconds: 0.50),
      NoteEvent(pitch: 67, startSeconds: 0.50, durationSeconds: 0.25),
      NoteEvent(pitch: 69, startSeconds: 0.75, durationSeconds: 0.25),
      NoteEvent(pitch: 71, startSeconds: 1.00, durationSeconds: 0.25),
      NoteEvent(pitch: 72, startSeconds: 1.25, durationSeconds: 0.25),
      NoteEvent(pitch: 74, startSeconds: 1.50, durationSeconds: 0.50),
      NoteEvent(pitch: 67, startSeconds: 2.00, durationSeconds: 0.50),
      NoteEvent(pitch: 67, startSeconds: 2.50, durationSeconds: 0.50),
      NoteEvent(pitch: 76, startSeconds: 3.00, durationSeconds: 0.50),
      NoteEvent(pitch: 72, startSeconds: 3.50, durationSeconds: 0.25),
      NoteEvent(pitch: 74, startSeconds: 3.75, durationSeconds: 0.25),
      NoteEvent(pitch: 76, startSeconds: 4.00, durationSeconds: 0.25),
      NoteEvent(pitch: 77, startSeconds: 4.25, durationSeconds: 0.25),
      NoteEvent(pitch: 79, startSeconds: 4.50, durationSeconds: 0.50),
      NoteEvent(pitch: 67, startSeconds: 5.00, durationSeconds: 0.50),
      NoteEvent(pitch: 67, startSeconds: 5.50, durationSeconds: 0.50),
    ],
  ),
  'turca': SongData(
    title: 'Mozart — Rondo Alla Turca',
    bpm: 130,
    notes: [
      NoteEvent(pitch: 71, startSeconds: 0.0, durationSeconds: 0.20),
      NoteEvent(pitch: 69, startSeconds: 0.20, durationSeconds: 0.20),
      NoteEvent(pitch: 68, startSeconds: 0.40, durationSeconds: 0.20),
      NoteEvent(pitch: 69, startSeconds: 0.60, durationSeconds: 0.20),
      NoteEvent(pitch: 72, startSeconds: 0.80, durationSeconds: 0.50),
      NoteEvent(pitch: 74, startSeconds: 1.40, durationSeconds: 0.20),
      NoteEvent(pitch: 72, startSeconds: 1.60, durationSeconds: 0.20),
      NoteEvent(pitch: 71, startSeconds: 1.80, durationSeconds: 0.20),
      NoteEvent(pitch: 72, startSeconds: 2.00, durationSeconds: 0.20),
      NoteEvent(pitch: 76, startSeconds: 2.20, durationSeconds: 0.50),
    ],
  ),
};

const int kMinPitch = 48; // C3
const int kMaxPitch = 84; // C6
const int kTotalWhiteKeys = 22;

bool isBlackKey(int pitch) {
  final idx = pitch % 12;
  return idx == 1 || idx == 3 || idx == 6 || idx == 8 || idx == 10;
}

String getNoteName(int pitch) {
  const names = ['C', 'C#', 'D', 'D#', 'E', 'F', 'F#', 'G', 'G#', 'A', 'A#', 'B'];
  final name = names[pitch % 12];
  final oct = (pitch ~/ 12) - 1;
  return '$name$oct';
}

class PianoPracticeApp extends StatelessWidget {
  const PianoPracticeApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Piano Practice with AI',
      debugShowCheckedModeBanner: false,
      theme: ThemeData.dark().copyWith(
        scaffoldBackgroundColor: const Color(0xFF020617),
        appBarTheme: const AppBarTheme(
          backgroundColor: Color(0xFF0F172A),
          elevation: 0,
        ),
      ),
      home: const PianoScreen(),
    );
  }
}

class PianoScreen extends StatefulWidget {
  const PianoScreen({super.key});

  @override
  State<PianoScreen> createState() => _PianoScreenState();
}

class _PianoScreenState extends State<PianoScreen> with SingleTickerProviderStateMixin {
  late Ticker _ticker;
  double _currentTime = 0.0;
  bool _isPlaying = false;
  double _tempo = 1.0;
  String _selectedSongKey = 'fur_elise';

  int _score = 0;
  int _streak = 0;
  int _maxStreak = 0;
  int _notesHit = 0;
  int _misses = 0;
  String _judgment = 'READY';
  Color _judgmentColor = Colors.white54;

  bool _isPremium = false;

  final Set<int> _activeUserPitches = {};
  final Set<int> _activeSongPitches = {};
  late List<NoteEvent> _currentNotes;

  @override
  void initState() {
    super.initState();
    _loadSong(_selectedSongKey);
    _ticker = createTicker(_onTick)..start();
  }

  void _loadSong(String songKey) {
    setState(() {
      _selectedSongKey = songKey;
      _currentTime = 0.0;
      _score = 0;
      _streak = 0;
      _maxStreak = 0;
      _notesHit = 0;
      _misses = 0;
      _judgment = 'READY';
      _judgmentColor = Colors.white54;
      _activeUserPitches.clear();
      _activeSongPitches.clear();
      _currentNotes = kSongs[songKey]!.notes.map((n) => n.copy()).toList();
    });
  }

  void _onTick(Duration elapsed) {
    if (!_isPlaying) return;

    setState(() {
      _currentTime += (1.0 / 60.0) * _tempo;

      for (final note in _currentNotes) {
        if (note.status == NoteHitStatus.pending && _currentTime > note.startSeconds + note.durationSeconds + 0.25) {
          note.status = NoteHitStatus.miss;
          _misses++;
          _streak = 0;
          _judgment = 'MISS';
          _judgmentColor = const Color(0xFFEF4444);
        }
      }

      _activeSongPitches.clear();
      for (final note in _currentNotes) {
        if (_currentTime >= note.startSeconds && _currentTime <= note.startSeconds + note.durationSeconds) {
          _activeSongPitches.add(note.pitch);
        }
      }

      final last = _currentNotes.last;
      if (_currentTime > last.startSeconds + last.durationSeconds + 1.2) {
        _isPlaying = false;
        _showCompletionDialog();
      }
    });
  }

  void _onUserKeyPress(int pitch) {
    setState(() {
      _activeUserPitches.add(pitch);

      if (!_isPlaying) return;

      const tolerance = 0.28;
      NoteEvent? closest;
      double minDelta = double.infinity;

      for (final note in _currentNotes) {
        if (note.pitch == pitch && note.status == NoteHitStatus.pending) {
          final delta = note.startSeconds - _currentTime;
          if (delta.abs() < minDelta.abs()) {
            minDelta = delta;
            closest = note;
          }
        }
      }

      if (closest != null && minDelta.abs() <= tolerance) {
        _notesHit++;
        _streak++;
        if (_streak > _maxStreak) _maxStreak = _streak;

        if (minDelta.abs() <= 0.08) {
          closest.status = NoteHitStatus.perfect;
          _score += 100 + min(50, _streak * 2);
          _judgment = 'PERFECT! +100';
          _judgmentColor = const Color(0xFF10B981);
        } else {
          closest.status = NoteHitStatus.good;
          _score += 50 + min(25, _streak);
          _judgment = 'GOOD! +50';
          _judgmentColor = const Color(0xFF22D3EE);
        }
      } else {
        _streak = 0;
        _judgment = 'MISS';
        _judgmentColor = const Color(0xFFEF4444);
      }
    });
  }

  void _onUserKeyRelease(int pitch) {
    setState(() {
      _activeUserPitches.delete(pitch);
    });
  }

  void _showCompletionDialog() {
    final attempts = _notesHit + _misses;
    final acc = attempts > 0 ? ((_notesHit / attempts) * 100).toStringAsFixed(1) : '100.0';

    showDialog(
      context: context,
      builder: (_) => AlertDialog(
        backgroundColor: const Color(0xFF0F172A),
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16), side: const BorderSide(color: Color(0xFF22D3EE))),
        title: const Text('Performance Report', style: TextStyle(color: Colors.white, fontWeight: FontWeight.bold)),
        content: Column(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text('Piece: ${kSongs[_selectedSongKey]!.title}', style: const TextStyle(color: Colors.white70)),
            const SizedBox(height: 8),
            Text('Final Score: $_score', style: const TextStyle(color: Color(0xFF22D3EE), fontSize: 18, fontWeight: FontWeight.bold)),
            Text('Accuracy: $acc%', style: const TextStyle(color: Color(0xFF10B981), fontSize: 18, fontWeight: FontWeight.bold)),
            Text('Streak: ${_maxStreak}x', style: const TextStyle(color: Color(0xFFF59E0B), fontSize: 18, fontWeight: FontWeight.bold)),
          ],
        ),
        actions: [
          TextButton(
            onPressed: () {
              Navigator.pop(context);
              _loadSong(_selectedSongKey);
            },
            child: const Text('Practice Again', style: TextStyle(color: Color(0xFF22D3EE))),
          ),
        ],
      ),
    );
  }

  void _openPaywall() {
    showDialog(
      context: context,
      builder: (_) => Dialog(
        backgroundColor: const Color(0xFF0F172A),
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(20), side: const BorderSide(color: Color(0xFFF59E0B), width: 1.5)),
        child: Padding(
          padding: const EdgeInsets.all(22.0),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            crossAxisAlignment: CrossAxisAlignment.stretch,
            children: [
              Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  const Row(
                    children: [
                      Icon(Icons.stars, color: Color(0xFFF59E0B), size: 26),
                      SizedBox(width: 8),
                      Text('Piano VIP Pass', style: TextStyle(color: Colors.white, fontSize: 18, fontWeight: FontWeight.bold)),
                    ],
                  ),
                  IconButton(
                    icon: const Icon(Icons.close, color: Colors.white54),
                    onPressed: () => Navigator.pop(context),
                  ),
                ],
              ),
              const Text('Piano Practice with AI — Designed by Ali Jedo', style: TextStyle(color: Color(0xFF22D3EE), fontSize: 12, fontWeight: FontWeight.bold)),
              const SizedBox(height: 12),
              const Text(
                'Unlock full classical masterworks, real-time AI practice critique, and advanced multi-touch controls.',
                style: TextStyle(color: Colors.white70, fontSize: 12, height: 1.3),
              ),
              const SizedBox(height: 16),
              Container(
                padding: const EdgeInsets.all(12),
                decoration: BoxDecoration(
                  color: const Color(0xFF451A03),
                  borderRadius: BorderRadius.circular(10),
                  border: Border.all(color: const Color(0xFFF59E0B)),
                ),
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    const Text('Annual Pass (Best Value)', style: TextStyle(color: Colors.white, fontSize: 12, fontWeight: FontWeight.bold)),
                    Text(r'$5.99/mo', style: const TextStyle(color: Color(0xFFF59E0B), fontWeight: FontWeight.bold)),
                  ],
                ),
              ),
              const SizedBox(height: 18),
              ElevatedButton(
                style: ElevatedButton.styleFrom(
                  backgroundColor: const Color(0xFFF59E0B),
                  foregroundColor: Colors.black,
                  padding: const EdgeInsets.symmetric(vertical: 12),
                  shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(10)),
                ),
                onPressed: () {
                  setState(() => _isPremium = true);
                  Navigator.pop(context);
                  ScaffoldMessenger.of(context).showSnackBar(
                    const SnackBar(content: Text('7-Day Free Trial Activated! Welcome to Premium.')),
                  );
                },
                child: const Text('Start 7-Day Free Trial Now', style: TextStyle(fontWeight: FontWeight.bold, fontSize: 14)),
              ),
            ],
          ),
        ),
      ),
    );
  }

  @override
  void dispose() {
    _ticker.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final attempts = _notesHit + _misses;
    final acc = attempts > 0 ? ((_notesHit / attempts) * 100).toStringAsFixed(1) : '100.0';
    final isLandscape = MediaQuery.of(context).orientation == Orientation.landscape;

    return Scaffold(
      appBar: AppBar(
        title: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: const [
            Text('Piano Practice with AI', style: TextStyle(fontWeight: FontWeight.bold, fontSize: 15)),
            Text('Designed by Ali Jedo', style: TextStyle(color: Color(0xFF22D3EE), fontSize: 10, fontWeight: FontWeight.w600)),
          ],
        ),
        actions: [
          TextButton.icon(
            icon: const Icon(Icons.star, color: Color(0xFFF59E0B), size: 16),
            label: Text(
              _isPremium ? 'Trial Active (7d)' : '7-Day Free Trial',
              style: const TextStyle(color: Color(0xFFF59E0B), fontWeight: FontWeight.bold, fontSize: 11),
            ),
            onPressed: _openPaywall,
          ),
          IconButton(
            icon: Icon(_isPlaying ? Icons.pause_circle_filled : Icons.play_circle_filled, color: const Color(0xFF22D3EE), size: 28),
            onPressed: () => setState(() => _isPlaying = !_isPlaying),
          ),
          IconButton(
            icon: const Icon(Icons.refresh, color: Colors.white70, size: 20),
            onPressed: () => _loadSong(_selectedSongKey),
          ),
        ],
      ),
      body: SafeArea(
        child: Column(
          children: [
            // Controls bar (Song & Tempo)
            Container(
              padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 4),
              color: const Color(0xFF0F172A),
              child: Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  DropdownButton<String>(
                    value: _selectedSongKey,
                    dropdownColor: const Color(0xFF1E293B),
                    style: const TextStyle(color: Colors.white, fontSize: 12),
                    underline: const SizedBox(),
                    onChanged: (val) {
                      if (val != null) _loadSong(val);
                    },
                    items: kSongs.entries.map((e) => DropdownMenuItem(value: e.key, child: Text(e.value.title))).toList(),
                  ),
                  Row(
                    children: [
                      const Text('Tempo: ', style: TextStyle(color: Colors.white54, fontSize: 11)),
                      DropdownButton<double>(
                        value: _tempo,
                        dropdownColor: const Color(0xFF1E293B),
                        style: const TextStyle(color: Color(0xFF22D3EE), fontSize: 12, fontWeight: FontWeight.bold),
                        underline: const SizedBox(),
                        onChanged: (val) {
                          if (val != null) setState(() => _tempo = val);
                        },
                        items: const [
                          DropdownMenuItem(value: 0.5, child: Text('0.5x')),
                          DropdownMenuItem(value: 0.75, child: Text('0.75x')),
                          DropdownMenuItem(value: 1.0, child: Text('1.0x')),
                          DropdownMenuItem(value: 1.25, child: Text('1.25x')),
                        ],
                      ),
                    ],
                  ),
                ],
              ),
            ),

            // Real-time HUD banner
            Container(
              padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 6),
              color: const Color(0xFF020617),
              child: Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  Row(
                    children: [
                      Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          const Text('SCORE', style: TextStyle(color: Colors.white38, fontSize: 8, fontWeight: FontWeight.bold)),
                          Text('$_score', style: const TextStyle(color: Color(0xFF22D3EE), fontSize: 15, fontWeight: FontWeight.bold)),
                        ],
                      ),
                      const SizedBox(width: 14),
                      Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          const Text('ACCURACY', style: TextStyle(color: Colors.white38, fontSize: 8, fontWeight: FontWeight.bold)),
                          Text('$acc%', style: const TextStyle(color: Color(0xFF10B981), fontSize: 15, fontWeight: FontWeight.bold)),
                        ],
                      ),
                      const SizedBox(width: 14),
                      Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          const Text('STREAK', style: TextStyle(color: Colors.white38, fontSize: 8, fontWeight: FontWeight.bold)),
                          Text('${_streak}x', style: const TextStyle(color: Color(0xFFF59E0B), fontSize: 15, fontWeight: FontWeight.bold)),
                        ],
                      ),
                    ],
                  ),
                  Text(_judgment, style: TextStyle(color: _judgmentColor, fontWeight: FontWeight.bold, fontSize: 13)),
                ],
              ),
            ),

            // Falling Notes Canvas
            Expanded(
              child: LayoutBuilder(
                builder: (context, constraints) {
                  return Stack(
                    children: [
                      CustomPaint(
                        size: Size(constraints.maxWidth, constraints.maxHeight),
                        painter: WaterfallPainter(
                          notes: _currentNotes,
                          currentTime: _currentTime,
                          totalWidth: constraints.maxWidth,
                          totalHeight: constraints.maxHeight,
                        ),
                      ),
                      Positioned(
                        bottom: 0,
                        left: 0,
                        right: 0,
                        child: Container(
                          height: 3,
                          decoration: const BoxDecoration(
                            color: Color(0xFF22D3EE),
                            boxShadow: [
                              BoxShadow(color: Color(0xFF22D3EE), blurRadius: 10, spreadRadius: 2),
                            ],
                          ),
                        ),
                      ),
                    ],
                  );
                },
              ),
            ),

            // Interactive Piano Keyboard (Responsive to Phones & Tablets)
            SizedBox(
              height: isLandscape ? 120 : 155,
              child: LayoutBuilder(
                builder: (context, constraints) {
                  final whiteKeyWidth = constraints.maxWidth / kTotalWhiteKeys;
                  final blackKeyWidth = whiteKeyWidth * 0.65;
                  final blackKeyHeight = isLandscape ? 76.0 : 98.0;

                  int whiteIdx = 0;
                  final List<Widget> keyWidgets = [];

                  // White Keys
                  for (int pitch = kMinPitch; pitch <= kMaxPitch; pitch++) {
                    if (!isBlackKey(pitch)) {
                      final currentIdx = whiteIdx;
                      final isUserActive = _activeUserPitches.contains(pitch);
                      final isSongActive = _activeSongPitches.contains(pitch);

                      Color bg = Colors.white;
                      if (isUserActive) bg = const Color(0xFFA5F3FC);
                      if (isSongActive) bg = const Color(0xFFDDD6FE);

                      keyWidgets.add(
                        Positioned(
                          left: currentIdx * whiteKeyWidth,
                          top: 0,
                          width: whiteKeyWidth,
                          height: isLandscape ? 120 : 155,
                          child: GestureDetector(
                            onTapDown: (_) => _onUserKeyPress(pitch),
                            onTapUp: (_) => _onUserKeyRelease(pitch),
                            onTapCancel: () => _onUserKeyRelease(pitch),
                            child: Container(
                              margin: const EdgeInsets.symmetric(horizontal: 0.5),
                              decoration: BoxDecoration(
                                color: bg,
                                borderRadius: const BorderRadius.vertical(bottom: Radius.circular(5)),
                                border: Border.all(color: Colors.black26),
                                boxShadow: [
                                  if (isUserActive || isSongActive)
                                    BoxShadow(
                                      color: isUserActive ? const Color(0xFF22D3EE) : const Color(0xFFA855F7),
                                      blurRadius: 12,
                                      spreadRadius: 2,
                                    ),
                                ],
                              ),
                              alignment: Alignment.bottomCenter,
                              padding: const EdgeInsets.only(bottom: 5),
                              child: Text(
                                getNoteName(pitch),
                                style: TextStyle(
                                  color: Colors.grey[800],
                                  fontSize: isLandscape ? 8 : 9,
                                  fontWeight: FontWeight.bold,
                                ),
                              ),
                            ),
                          ),
                        ),
                      );
                      whiteIdx++;
                    }
                  }

                  // Black Keys
                  whiteIdx = 0;
                  for (int pitch = kMinPitch; pitch < kMaxPitch; pitch++) {
                    if (!isBlackKey(pitch)) {
                      whiteIdx++;
                    } else {
                      final isUserActive = _activeUserPitches.contains(pitch);
                      final isSongActive = _activeSongPitches.contains(pitch);

                      Color bg = const Color(0xFF0F172A);
                      if (isUserActive) bg = const Color(0xFF0891B2);
                      if (isSongActive) bg = const Color(0xFF7C3AED);

                      final left = (whiteIdx * whiteKeyWidth) - (blackKeyWidth / 2);

                      keyWidgets.add(
                        Positioned(
                          left: left,
                          top: 0,
                          width: blackKeyWidth,
                          height: blackKeyHeight,
                          child: GestureDetector(
                            onTapDown: (_) => _onUserKeyPress(pitch),
                            onTapUp: (_) => _onUserKeyRelease(pitch),
                            onTapCancel: () => _onUserKeyRelease(pitch),
                            child: Container(
                              decoration: BoxDecoration(
                                color: bg,
                                borderRadius: const BorderRadius.vertical(bottom: Radius.circular(4)),
                                border: Border.all(color: Colors.black, width: 1.5),
                                boxShadow: [
                                  const BoxShadow(color: Colors.black54, blurRadius: 4, offset: Offset(1, 2)),
                                  if (isUserActive || isSongActive)
                                    BoxShadow(
                                      color: isUserActive ? const Color(0xFF22D3EE) : const Color(0xFFA855F7),
                                      blurRadius: 12,
                                      spreadRadius: 2,
                                    ),
                                ],
                              ),
                              alignment: Alignment.bottomCenter,
                              padding: const EdgeInsets.only(bottom: 3),
                              child: Text(
                                getNoteName(pitch),
                                style: const TextStyle(
                                  color: Color(0xFF22D3EE),
                                  fontSize: 6,
                                  fontWeight: FontWeight.bold,
                                ),
                              ),
                            ),
                          ),
                        ),
                      );
                    }
                  }

                  return Stack(children: keyWidgets);
                },
              ),
            ),
          ],
        ),
      ),
    );
  }
}

class WaterfallPainter extends CustomPainter {
  final List<NoteEvent> notes;
  final double currentTime;
  final double totalWidth;
  final double totalHeight;

  WaterfallPainter({
    required this.notes,
    required this.currentTime,
    required this.totalWidth,
    required this.totalHeight,
  });

  @override
  void paint(Canvas canvas, Size size) {
    final whiteKeyWidth = totalWidth / kTotalWhiteKeys;
    final blackKeyWidth = whiteKeyWidth * 0.65;
    const secondsInView = 2.4;
    final pixelsPerSecond = totalHeight / secondsInView;

    for (final note in notes) {
      final timeUntilHit = note.startSeconds - currentTime;
      final noteDurationPx = max(14.0, note.durationSeconds * pixelsPerSecond);
      final bottomY = totalHeight - (timeUntilHit * pixelsPerSecond);
      final topY = bottomY - noteDurationPx;

      if (bottomY < 0 || topY > totalHeight) continue;

      double x = 0;
      double w = 0;

      int whiteCount = 0;
      for (int p = kMinPitch; p < note.pitch; p++) {
        if (!isBlackKey(p)) whiteCount++;
      }

      if (!isBlackKey(note.pitch)) {
        x = whiteCount * whiteKeyWidth + 1.5;
        w = whiteKeyWidth - 3;
      } else {
        x = (whiteCount * whiteKeyWidth) - (blackKeyWidth / 2) + 1;
        w = blackKeyWidth - 2;
      }

      Color noteColor;
      if (note.status == NoteHitStatus.perfect) {
        noteColor = const Color(0xFF10B981);
      } else if (note.status == NoteHitStatus.good) {
        noteColor = const Color(0xFF22D3EE);
      } else if (note.status == NoteHitStatus.miss) {
        noteColor = const Color(0xFFEF4444).withOpacity(0.4);
      } else {
        noteColor = isBlackKey(note.pitch) ? const Color(0xFFA855F7) : const Color(0xFF22D3EE);
      }

      final rrect = RRect.fromRectAndRadius(
        Rect.fromLTWH(x, topY, w, noteDurationPx),
        const Radius.circular(5),
      );

      final paint = Paint()
        ..color = noteColor
        ..style = PaintingStyle.fill;

      canvas.drawRRect(rrect, paint);
    }
  }

  @override
  bool shouldRepaint(covariant WaterfallPainter oldDelegate) => true;
}
