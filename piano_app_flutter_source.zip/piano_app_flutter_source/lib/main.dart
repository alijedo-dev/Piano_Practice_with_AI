import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:webview_flutter/webview_flutter.dart';

void main() {
  WidgetsFlutterBinding.ensureInitialized();
  SystemChrome.setPreferredOrientations([
    DeviceOrientation.portraitUp,
    DeviceOrientation.portraitDown,
    DeviceOrientation.landscapeLeft,
    DeviceOrientation.landscapeRight,
  ]);
  runApp(const PianoPracticeApp());
}

class PianoPracticeApp extends StatelessWidget {
  const PianoPracticeApp({super.key});

  @override
  Widget build(BuildContext context) {
    return const MaterialApp(
      title: 'Piano Practice with AI',
      debugShowCheckedModeBanner: false,
      home: PianoStudioScreen(),
    );
  }
}

class PianoStudioScreen extends StatefulWidget {
  const PianoStudioScreen({super.key});

  @override
  State<PianoStudioScreen> createState() => _PianoStudioScreenState();
}

class _PianoStudioScreenState extends State<PianoStudioScreen> {
  late final WebViewController _controller;

  @override
  void initState() {
    super.initState();
    _controller = WebViewController()
      ..setJavaScriptMode(JavaScriptMode.unrestricted)
      ..setBackgroundColor(const Color(0xFF020617))
      ..loadFlutterAsset('assets/index.html');
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xFF020617),
      body: SafeArea(
        child: WebViewWidget(controller: _controller),
      ),
    );
  }
}
